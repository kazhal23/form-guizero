from guizero import App, Text, TextBox, PushButton, MenuBar, CheckBox, Box, ButtonGroup

def Signin_function():
    print("Sign in")

def signup_function():
    print("Sign up")

def Login_function():
    print("Log in")

def Logoff_function():
    print("Log off")

def submit_form():
    first_name = first_name_box.value
    last_name = last_name_box.value
    age = age_box.value
    year = year_box.value
    month = month_box.value
    selected_title = choice.value
    is_checked = check.value
    print(f"First Name: {first_name}, Last Name: {last_name}, Age: {age}, Year: {year}, Month: {month}, Title: {selected_title}, Terms Agreed: {is_checked}")

app = App(title='sign in', bg="#0000ff")

menubar = MenuBar(app,
                  toplevel=["Signin", "Signup", "Login", "Logoff"],
                  options=[
                      [ ["Sign in option 1", Signin_function], ["sign in option 1", Signin_function] ],
                      [ ["sign up option 1", signup_function], ["sign up option 2", signup_function] ],
                      [ ["Log in option  1",  Login_function], ["Log in  option 3", Login_function ] ],
                      [ ["Log off option 1", Logoff_function], ["Log off option 4", Logoff_function] ],
                  ])


main_box = Box(app, width="100", height="100", align="top", border=True)


Text(main_box, text="First Name:",color='white',size=10)
first_name_box = TextBox(main_box, width=40,height=1)
first_name_box.text_color='red'
first_name_box.bg='green'
Text(main_box, text="Last Name:",color='white',size=10)
last_name_box = TextBox(main_box, width=40,height=1)
last_name_box.text_color='red'
last_name_box.bg='green'
Text(main_box, text="Age:",color='white',size=10)
age_box = TextBox(main_box, width=5,height=1)
age_box.text_color='red'
age_box.bg='green'
Text(main_box, text="Year:",color='white',size=10)
year_box = TextBox(main_box, width=5,height=1)
year_box.text_color='red'
year_box.bg='green'
Text(main_box, text="Month:",color='white',size=10)
month_box = TextBox(main_box, width=5,height=1)
month_box.text_color='red'
month_box.bg='green'


box = Box(main_box)
choice = ButtonGroup(box, options=["MR", "Ms", "DR"], selected="MR",width=50,height=1)
check = CheckBox(box, text="Agree to Terms")
check.text_color='white'
choice.bg="green"
submit_button = PushButton(main_box, text="Submit", command=submit_form)
submit_button.bg='green'

app.display()